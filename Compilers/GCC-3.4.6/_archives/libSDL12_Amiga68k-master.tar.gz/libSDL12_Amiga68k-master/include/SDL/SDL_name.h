
#ifndef _SDLname_h_
#define _SDLname_h_

#if defined(__STDC__) || defined(__cplusplus)
#define NeedFunctionPrototypes 1
#endif

#define SDL_NAME(X)	SDL_##X

#endif /* _SDLname_h_ */
