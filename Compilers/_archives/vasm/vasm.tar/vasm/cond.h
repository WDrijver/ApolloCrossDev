/* cond.h - conditional assembly support routines */
/* (c) in 2015,2023,2026 by Frank Wille */

#ifndef COND_H
#define COND_H

/* defines */
#ifndef MAXCONDLEV
#define MAXCONDLEV 63
#endif

/* global variables */
extern int clev,cond_trace;

/* functions */
void cond_init(void);
int cond_state(void);
void cond_check(void);
void cond_if(char);
void cond_skipif(void);
void cond_else(void);
void cond_skipelse(void);
void cond_elseif(char);
void cond_endif(void);

#endif /* COND_H */
